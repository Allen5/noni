#!/usr/bin/python
# coding=utf8

"""
@desc: 测试入口
@author: Allen.Wu
@email: allenlikeu@gmail.com
@time: 2016-06-03
"""
import unittest
if __name__ == "__main__":
    unittest.main()
